# Codex handoff — implementation stage

## Current state

v0.2 is a standard-library Python proof of the authority architecture. The unit suite covers exact-use, replay, widening, cross-session, cross-executor, expiry, malformed requests, prohibited operations, permissive-guardian failure, and record tampering.

## Highest-priority engineering tasks

1. **Process split**
   - Run Neural Link Zero, guardian quorum, capability broker, executor, and recorder as separate OS processes.
   - Define a minimal length-prefixed canonical protocol; no HTTP in the trusted path.

2. **Rust trusted core**
   - Port request parsing, canonical serialization, policy evaluation, capability claims, and verification to Rust.
   - Keep Python for range orchestration and experiments.
   - Add differential canonicalization tests between independent implementations.

3. **Asymmetric and hardware-backed capability signing**
   - Replace HMAC with Ed25519 for development.
   - Bind production issuance to HardProof/TPM or enclave attestation.
   - Ensure the executor only receives the verifier public key.

4. **Real execution cell**
   - Build a Firecracker microVM image with read-only root, ephemeral scratch, no package manager, no host mounts, no metadata, and no network device.
   - Use vsock only for fixed protocol messages.

5. **Authority-empty sacrificial host**
   - No cloud role, Kubernetes membership, registry credentials, production routes, adjacent tenants, or reachable BMC.
   - External watchdog resets the host after every run.

6. **One-way evidence plane**
   - Replace local recorder path with a one-way receiver on separate hardware/account.
   - Add fixed-size telemetry frames, sequence numbers, loss detection, and signed receipt acknowledgements that cannot carry arbitrary data back.

7. **Synthetic escape range**
   - Implement fake package proxy, metadata service, service account, neighboring worker, audit service, and control plane.
   - All credentials must be synthetic and cryptographically scoped to the range.

8. **Compromise injector**
   - Start campaigns at process control, guest root, kernel control, VM escape, host root, one guardian compromised, signer unavailable, and human misapproval.

9. **Closed-loop remediation integration**
   - Run the uploaded Iaso reproducer as a permitted workload.
   - Make baseline replay, patch validation, reattack, and promotion evidence flow through Event Horizon capabilities.

10. **Containment Certificate v1**
    - Include authority graph before/after, image/policy/TCB digests, capability inventory, denied transitions, egress-bit accounting, teardown proof, recorder verification, and detached signature.

## Acceptance criteria for next release

- Root inside a route-less microVM is demonstrated.
- Capability theft does not permit replay, widening, transfer, or expiry bypass.
- The guest has zero ambient credentials and zero network interface.
- The sacrificial host has no external identity or useful route.
- The external recorder survives guest and host-local tampering.
- A clean machine can reproduce the demonstration from documented commands.
