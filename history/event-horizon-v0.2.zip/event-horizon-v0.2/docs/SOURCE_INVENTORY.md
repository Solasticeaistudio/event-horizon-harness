# Solstice source inventory and disposition

This inventory records what Event Horizon v0.2 borrows conceptually from the uploaded Solstice systems and what must be excluded from the trusted computing base.

| Source | Useful contribution | Event Horizon disposition |
|---|---|---|
| Neural Link | Single action choke point, capability vocabulary, rate limiting, circuit breakers, event hooks | Rewrite as Neural Link Zero. Remove dynamic tool registration, direct handlers, live/simulation switching, and execution authority. |
| Astraea | Structured policies, audit concepts, approvals, risk vocabulary | Use as an offline policy-authoring plane only. Never place LLM policy generation or fail-open clients in the authorization path. |
| Talos | Threat taxonomy, prompt/tool screening, audit events | Advisory/veto signal only. Current advisory/off modes and fail-open behavior disqualify it as a security boundary. |
| Guardrails | Tool risk taxonomy and approval UX | Use for experiment authoring and human explanations. Local log files and regex checks are not containment boundaries. |
| Delta / DeltaContextStore | Branching, replay, append-oriented snapshots, time travel | Use for replay/counterfactual analysis outside the hostile world. Keep the authoritative recorder independent and hash chained. |
| Proof | Event-chain linkage, snapshots, integrity verification | Reuse proof vocabulary and verification concepts for the Containment Certificate. |
| Assurance | Canonical digests, manifests, detached signatures, evidence bundles, provenance, attack suites | Strongest evidence-layer donor. Replace development HMAC with hardware-backed asymmetric signing in production. |
| Phalanx | Security graph, sensors, threat correlation, proof recording, orchestration | Use as the outer control plane and authority-graph owner, not inside the hostile host. |
| Iaso / closed-loop remediation | Baseline attack, patch, reattack, promotion policy, signed requests, evidence packaging | Integrate as the safe closed-loop workload running through Event Horizon. |
| Nemesis | Adversarial campaigns, sandbox concepts, connectors, attack generation | Use only inside the synthetic escape range. No real external connectors in Black Hole mode. |
| Aegis | Defensive swarm, validation, budgets, Nemesis bridge, response orchestration | Adapt to lineage-wide budgets and independent vetoes. Model/swarm consensus cannot mint authority. |
| Ares deception | Honeytokens, fake credentials, fake services, attack-stage tracking | Reuse for the synthetic range and compromise demonstrations. |
| Ares cloud-native / zero-trust | Container escape, service-account abuse, metadata, lateral movement, segmentation vocabulary | Convert threat types into injected-compromise scenarios and certificate assertions. |
| Sentinel / Argus | Signal normalization, temporal fusion, risk scoring, monitoring | Observability and experiment analysis outside the authorization TCB. |
| Agent Mesh | Agent lineage, delegation, event flow | Never expose the production mesh to the hostile workload. Use a synthetic mesh and global lineage identifier in the range. |
| Cerberus | Agent policy/gateway concept | Replace with a minimal deterministic policy guardian. |
| SOAR integrations | Incident/export destinations | Remain outside containment; only receive sanitized signed findings after policy approval. |

## Critical unsafe defaults found

- The existing Talos service supports `advisory` and `off` modes and fail-open handling for selected agents.
- The existing Astraea SDK returns an allowed result when its HTTP client is unavailable.
- The existing Neural Link owns real callable handlers and can switch execution modes.
- Several audit stores are local to the application or rely on general-purpose databases reachable by the application.
- Model-generated policy and model-based security classification are probabilistic and therefore cannot authorize operations.

These are normal product compromises. Event Horizon requires fail-closed behavior and a substantially smaller trusted core.
