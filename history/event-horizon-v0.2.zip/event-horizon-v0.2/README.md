# Event Horizon v0.2

Event Horizon is a compromise-tolerant containment research harness for autonomous agents.

Its central claim is intentionally narrower and stronger than “the sandbox cannot be escaped”:

> Complete compromise of the agent workload must not grant transferable authority, unrestricted egress, durable persistence, cross-session influence, or control over authoritative evidence.

The v0.2 prototype tests the **authority architecture** before adding Firecracker, TPM attestation, physical network separation, or dedicated hardware. It deliberately assumes the hostile workload can read every local file and obtain root inside its assigned environment.

## What works now

- Strict, typed action requests with unknown-field rejection
- Neural Link Zero: canonicalization only; no dynamic tools, shell, URLs, HTTP, secrets, or direct execution
- Deny-by-default static policy evaluation
- Guardian quorum where any veto blocks and no guardian can widen policy
- Short-lived, one-use capabilities bound to session, executor measurement, operation, resource, and exact argument digest
- Replay, widening, cross-session, cross-executor, expiry, malformed-request, and tamper tests
- External append-only hash-chained recorder
- Signed prototype Containment Certificate
- Synthetic honey credential and “assumed root” demonstration

## Run

```bash
python -m unittest discover -s tests -v
PYTHONPATH=src python -m event_horizon.demo
```

Or install editable:

```bash
python -m pip install -e .
event-horizon-demo
```

## Important limits

This prototype does **not** claim hardware isolation. HMAC is used as a local stand-in for hardware-backed signing. The execution cell is simulated. The next implementation stage replaces process boundaries with route-less microVMs and moves signing/recording outside the hostile host.

See `docs/THREAT_MODEL.md`, `docs/ARCHITECTURE.md`, and `docs/CODEX_HANDOFF.md`.
