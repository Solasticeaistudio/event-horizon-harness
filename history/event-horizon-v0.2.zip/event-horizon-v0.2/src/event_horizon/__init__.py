"""Event Horizon compromise-tolerant authority containment prototype."""

__version__ = "0.2.0"
