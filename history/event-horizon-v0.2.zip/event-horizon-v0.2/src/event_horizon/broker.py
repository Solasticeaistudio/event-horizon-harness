from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import threading
import time
from dataclasses import asdict
from typing import Any

from .canonical import canonical_bytes, digest
from .models import ActionRequest, CapabilityClaims, IssuedCapability


class CapabilityError(PermissionError):
    pass


class CapabilityBroker:
    """Prototype external capability mint and verifier.

    The signing key must never exist inside the hostile execution environment.
    HMAC is a development stand-in for hardware-backed asymmetric signing.
    """

    def __init__(self, signing_key: bytes, key_id: str = "dev-hmac", ttl_seconds: float = 10.0):
        if len(signing_key) < 32:
            raise ValueError("signing key must be at least 32 bytes")
        self._key = signing_key
        self.key_id = key_id
        self.ttl_seconds = ttl_seconds
        self._consumed: set[str] = set()
        self._lock = threading.RLock()

    def issue(
        self,
        request: ActionRequest,
        *,
        executor_measurement: str,
        policy_digest: str,
        max_output_bytes: int,
        now: float | None = None,
    ) -> IssuedCapability:
        now = time.time() if now is None else now
        claims = CapabilityClaims(
            capability_id=f"cap_{secrets.token_hex(12)}",
            issued_at=now,
            expires_at=now + self.ttl_seconds,
            session_id=request.session_id,
            agent_id=request.agent_id,
            executor_id=request.executor_id,
            executor_measurement=executor_measurement,
            operation=request.operation,
            resource_id=request.resource_id,
            arguments_digest=digest(dict(request.arguments)),
            request_digest=request.request_digest,
            max_output_bytes=max_output_bytes,
            invocation_limit=1,
            policy_digest=policy_digest,
        )
        signature = hmac.new(self._key, canonical_bytes(claims.to_dict()), hashlib.sha256).hexdigest()
        return IssuedCapability(claims=claims, signature=signature, key_id=self.key_id)

    def verify_and_consume(
        self,
        capability: IssuedCapability,
        request: ActionRequest,
        *,
        executor_measurement: str,
        now: float | None = None,
    ) -> CapabilityClaims:
        now = time.time() if now is None else now
        claims = capability.claims
        expected = hmac.new(self._key, canonical_bytes(claims.to_dict()), hashlib.sha256).hexdigest()
        if capability.key_id != self.key_id or not hmac.compare_digest(expected, capability.signature):
            raise CapabilityError("invalid capability signature")
        if now > claims.expires_at:
            raise CapabilityError("capability expired")
        if claims.invocation_limit != 1:
            raise CapabilityError("unsupported invocation limit")
        bindings = {
            "session_id": (claims.session_id, request.session_id),
            "agent_id": (claims.agent_id, request.agent_id),
            "executor_id": (claims.executor_id, request.executor_id),
            "executor_measurement": (claims.executor_measurement, executor_measurement),
            "operation": (claims.operation, request.operation),
            "resource_id": (claims.resource_id, request.resource_id),
            "arguments_digest": (claims.arguments_digest, digest(dict(request.arguments))),
            "request_digest": (claims.request_digest, request.request_digest),
        }
        mismatches = [name for name, (expected_value, actual_value) in bindings.items() if expected_value != actual_value]
        if mismatches:
            raise CapabilityError(f"capability binding mismatch: {sorted(mismatches)}")
        with self._lock:
            if claims.capability_id in self._consumed:
                raise CapabilityError("capability replay detected")
            self._consumed.add(claims.capability_id)
        return claims
