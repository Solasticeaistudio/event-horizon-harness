from __future__ import annotations

import hashlib
import hmac
import json
import time
from pathlib import Path
from typing import Any

from .canonical import canonical_bytes, digest
from .recorder import ExternalRecorder


class ContainmentCertificateBuilder:
    def __init__(self, recorder: ExternalRecorder, signing_key: bytes, key_id: str = "dev-certificate-hmac"):
        self.recorder = recorder
        self.signing_key = signing_key
        self.key_id = key_id

    def build(self, *, run_id: str, session_id: str, assertions: dict[str, bool]) -> dict[str, Any]:
        valid, tip = self.recorder.verify()
        events = self.recorder.events()
        denied = sum(1 for event in events if event["event_type"] in {"request.denied", "execution.denied", "request.rejected"})
        completed = sum(1 for event in events if event["event_type"] == "execution.completed")
        payload = {
            "schema": "event-horizon.containment-certificate.v0.2",
            "run_id": run_id,
            "session_id": session_id,
            "created_at": time.time(),
            "event_count": len(events),
            "event_chain_valid": valid,
            "event_chain_tip": tip,
            "completed_actions": completed,
            "denied_transitions": denied,
            "assertions": dict(sorted(assertions.items())),
        }
        signature = hmac.new(self.signing_key, canonical_bytes(payload), hashlib.sha256).hexdigest()
        return {"certificate": payload, "signature": signature, "key_id": self.key_id}

    def write(self, path: str | Path, **kwargs: Any) -> dict[str, Any]:
        result = self.build(**kwargs)
        Path(path).write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
        return result
