# v0.1 acceptance tests

## Parser and canonicalization

- Reject unknown top-level fields
- Reject unknown argument fields
- Reject oversized requests
- Reject unsupported versions and operations
- Reject malformed session IDs
- Produce stable canonical bytes and digest for equivalent accepted input

## Capability semantics

- Reject replay
- Reject expiration
- Reject modified arguments
- Reject modified resource
- Reject different operation
- Reject different executor measurement
- Reject different session or lineage

## Containment

- No direct network route from hostile cell
- No metadata endpoint
- No reusable credential in process, guest, or sacrificial host
- No cross-cell shared writable state
- Verified wipe and recreation after run

## Forensics

- Local log deletion does not alter external event chain
- Missing or reordered events are detectable
- Every released output maps to an approved capability and recorded decision
