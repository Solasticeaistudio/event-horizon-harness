use serde::{Deserialize, Serialize};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::io::{self, Read};
use thiserror::Error;

const MAX_REQUEST_BYTES: usize = 16 * 1024;

#[derive(Debug, Error)]
enum GateError {
    #[error("request exceeds byte limit")]
    TooLarge,
    #[error("invalid JSON: {0}")]
    Json(#[from] serde_json::Error),
    #[error("unsupported version")]
    Version,
    #[error("invalid session id")]
    Session,
    #[error("unsupported operation")]
    Operation,
    #[error("arguments do not match operation")]
    Arguments,
}

#[derive(Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct ActionRequest {
    version: String,
    session_id: String,
    sequence: u32,
    operation: String,
    resource: String,
    arguments: Value,
}

#[derive(Debug, Serialize)]
struct CanonicalRequest {
    request: ActionRequest,
    sha256: String,
}

fn validate(req: &ActionRequest) -> Result<(), GateError> {
    if req.version != "0.1" {
        return Err(GateError::Version);
    }
    if req.session_id.len() != 32 || !req.session_id.bytes().all(|b| b.is_ascii_hexdigit() && !b.is_ascii_uppercase()) {
        return Err(GateError::Session);
    }

    match req.operation.as_str() {
        "object.read" => {
            let obj = req.arguments.as_object().ok_or(GateError::Arguments)?;
            if obj.len() != 2 || !obj.contains_key("offset") || !obj.contains_key("length") {
                return Err(GateError::Arguments);
            }
            let length = obj.get("length").and_then(Value::as_u64).ok_or(GateError::Arguments)?;
            if length == 0 || length > 1_048_576 {
                return Err(GateError::Arguments);
            }
        }
        "compute.run" => {
            let obj = req.arguments.as_object().ok_or(GateError::Arguments)?;
            if obj.len() != 2 || !obj.contains_key("profile") || !obj.contains_key("input_ids") {
                return Err(GateError::Arguments);
            }
        }
        _ => return Err(GateError::Operation),
    }
    Ok(())
}

fn run() -> Result<(), GateError> {
    let mut input = Vec::new();
    io::stdin().take((MAX_REQUEST_BYTES + 1) as u64).read_to_end(&mut input).expect("stdin read failed");
    if input.len() > MAX_REQUEST_BYTES {
        return Err(GateError::TooLarge);
    }

    let request: ActionRequest = serde_json::from_slice(&input)?;
    validate(&request)?;

    // serde_json serialization of this fixed struct produces the canonical field order.
    let canonical = serde_json::to_vec(&request)?;
    let digest = hex::encode(Sha256::digest(&canonical));
    let output = CanonicalRequest { request, sha256: digest };
    println!("{}", serde_json::to_string(&output)?);
    Ok(())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("neural-link-zero: {error}");
        std::process::exit(1);
    }
}
