# Event Horizon v0.1

Compromise-tolerant containment and evaluation harness for frontier AI agents.

## Research claim

Event Horizon is designed so that complete compromise of an agent workload, and selected host-layer compromises, do not automatically provide:

1. transferable authority,
2. unrestricted network egress,
3. durable persistence,
4. cross-session or lateral influence, or
5. control over forensic evidence.

This is not a claim of mathematically perfect containment. It is a testable claim about preventing compromise from propagating across trust boundaries.

## Core idea

The model never receives ambient authority. It can propose typed intent through Neural Link Zero. Independent guardians may veto the request. A separate broker may mint a one-use capability bound to one attested executor, one operation, one object, one argument hash, and one short expiration window.

```text
Model / agent loop
       |
       | typed intent only
       v
Neural Link Zero
       |
       v
Guardian veto quorum
       |
       v
One-use capability broker
       |
       v
Sacrificial executor cell

External plane: immutable flight recorder + global kill controller
```

## Trust rule

Compromise of layer N must not automatically reveal the identity, credentials, communication path, or authority needed to compromise layer N+1.

## Repository map

- `docs/INVARIANTS.md`: five non-negotiable security invariants
- `docs/THREAT_MODEL.md`: attacker model, assets, trust zones, and failure taxonomy
- `docs/BUILD_PLAN.md`: scoped implementation and evaluation plan
- `schemas/action-request.schema.json`: initial typed intent envelope
- `policies/default-policy.yaml`: deny-by-default starter policy
- `components/neural-link-zero/`: minimal Rust trusted-computing-base scaffold
- `range/scenarios/`: synthetic containment-failure experiments
- `tests/`: acceptance and regression test plan

## v0.1 scope

The first prototype supports only two operations:

- `object.read`: read a bounded byte range from a pre-registered immutable object
- `compute.run`: run a pre-registered computation profile against pre-registered inputs

No arbitrary URLs, shell commands, package installation, dynamic plugins, credential forwarding, or direct model-to-network path are permitted.

## Success condition

The strongest useful demonstration is not that the agent never reaches root. It is that the agent can reach root in a deliberately vulnerable inner environment and still cannot acquire a reusable identity, contact an unauthorized system, persist after teardown, alter the audit record, or exceed the fixed output envelope.
