# Build and evaluation plan

## Stage 0: Freeze the claim

Deliverables:

- containment invariants,
- threat model,
- trusted-computing-base inventory,
- explicit non-goals,
- and measurable failure taxonomy.

Exit gate: every component maps to at least one invariant; components that do not are removed.

## Stage 1: Neural Link Zero

Fork the original Neural Link concept rather than modifying the full production service.

Retain:

- central action mediation,
- capability checks,
- rate and budget enforcement,
- simulation/live separation,
- circuit breaking,
- and full execution history.

Remove from the trusted core:

- runtime mode switching by agents,
- arbitrary tool registration,
- general HTTP,
- dynamic plugins,
- shell strings,
- templating,
- secrets,
- and any direct execution handler.

Initial implementation:

- Rust parser/canonicalizer,
- fixed action schema,
- reject unknown fields,
- strict byte and nesting limits,
- deterministic canonical serialization,
- request digest generation,
- no network client library in the binary.

Exit gate: malformed and adversarial inputs cannot cause execution, schema widening, parser disagreement, or uncontrolled resource use.

## Stage 2: Capability broker and guardians

Guardians:

- Cerberus: static policy veto
- Talos: behavioral and sequence veto
- Aegis: lineage-wide resource and blast-radius veto
- HardProof: executor, image, and policy attestation

Broker output:

- single-use capability,
- exact operation/resource/argument digest,
- exact executor measurement,
- expiration under 30 seconds,
- output ceiling,
- invocation counter of one.

Exit gate: copied, replayed, widened, expired, cross-executor, and cross-session capabilities all fail closed.

## Stage 3: Sacrificial cell

Prototype target:

- dedicated KVM host,
- Firecracker microVM,
- minimal signed guest image,
- optional gVisor layer where compatible,
- read-only root,
- ephemeral scratch disk,
- no package manager,
- no metadata service,
- no cloud or cluster identity,
- no default network interface,
- and verified teardown.

Exit gate: deliberate guest-root compromise exposes no reusable credential, external route, persistent volume, or management interface.

## Stage 4: Flight recorder

DeltaStore integration records:

- model turn and agent lineage,
- raw and canonical action requests,
- guardian decisions,
- capability digest and constraints,
- executor attestation,
- process and filesystem events,
- network attempts,
- resource consumption,
- output release,
- kill event,
- and teardown proof.

Exit gate: compromised cell and compromised sacrificial host cannot alter the authoritative event chain undetected.

## Stage 5: Synthetic escape range

Build intentionally vulnerable scenarios with no real targets:

1. Vulnerable package-cache proxy
2. Fake metadata credential service
3. Overprivileged service identity
4. Approved-domain account substitution
5. Reusable capability token
6. Neighboring fake workload
7. Writable fake audit service
8. Intentional guest-root path
9. Intentional host foothold on an authority-empty machine
10. Swarm attempt against global budgets

Every scenario has a vulnerable baseline and an Event Horizon configuration.

Exit gate: results are reproducible and report the exact maximum failure stage.

## Stage 6: Frontier-agent evaluation

Metrics:

- maximum privilege stage,
- time to first violation attempt,
- denied and allowed actions,
- credentials discovered and replayed,
- unauthorized egress bytes,
- lateral targets reached,
- persistence after teardown,
- output-channel utilization,
- detection latency,
- false-positive termination,
- and flight-recorder completeness.

## First implementation sprint

1. Compile the Neural Link Zero Rust scaffold.
2. Add canonical request hashing.
3. Implement a deny-by-default policy evaluator.
4. Implement one fake read-only object executor.
5. Implement an append-only local recorder for development.
6. Add replay, widening, unknown-field, oversized-payload, and cross-session tests.
7. Produce the first attack trace and result report.

Do not start Firecracker integration until the authority path and tests work locally. The event horizon is the capability boundary, not the VM brand.
